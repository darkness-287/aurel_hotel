# Aurel House - Member 5 (Front Desk)

Module demo cho Thanh vien 5, theo C++17 + Qt Widgets + SQLite.

## Chuc nang
- FR-19: Dashboard thong ke phong, booking va so khach.
- FR-20: Bao cao booking, tien thu, tien hoan, doanh thu rong,
  so dem phong co khach va tai khoan moi.
- FR-27: Verify Booking theo Booking ID; kiem tra Confirmed va Paid.
- FR-28: Check-in; booking CheckedIn, phong Occupied.
- FR-29: Check-out; booking Completed.
- FR-30: Chuyen phong Available sang Maintenance; xac nhan phong
  Cleaning/Maintenance tro lai Available.
- FR-31: Check-out thanh cong chuyen phong Occupied sang Cleaning.

## Yeu cau
- VS Code
- CMake
- Trinh bien dich C++17
- Qt 6 (modules Widgets va Sql)

## Build tren VS Code (Windows)
1. Cai Qt 6 va compiler phu hop (MinGW hoac MSVC).
2. Cai extension C/C++ va CMake Tools trong VS Code.
3. Mo thu muc HotelRoomBooking_Member5 bang VS Code.
4. Chon Configure CMake va chon Qt kit/compiler.
5. Build project, sau do Run.

Neu Qt chua duoc CMake tim thay, cau hinh CMAKE_PREFIX_PATH tro den thu muc Qt 6
co chua file Qt6Config.cmake.

## Du lieu demo
- Tai khoan Admin demo duoc gan trong MainWindow.cpp (userId=1, role=Admin).
  Khi ghep voi module Thanh vien 1, phai thay bang Session that tu AuthService.
- Booking mau: BK1001, phong 204, Confirmed, Paid.
- Room ID la khoa chinh trong database; Room number la ma hien thi.

## Luu y tich hop
Schema trong database/schema.sql la schema demo toi thieu de chay rieng module.
Khi ghep vao project nhom, can doi ten cot/bang va Session theo schema chung da duyet.
Khong dung tai khoan Admin demo trong ban nop chinh thuc.
Bao cao tien thu dang tinh tong total_amount cua booking Paid theo khoang ngay
co giao nhau voi ngay luu tru; nhom can thong nhat quy tac ghi nhan doanh thu
voi module thanh toan.