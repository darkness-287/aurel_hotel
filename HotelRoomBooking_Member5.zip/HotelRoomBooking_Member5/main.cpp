#include "src/MainWindow.h"
#include <QApplication>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDir>
#include <QFile>

static bool initializeDatabase()
{
    QDir().mkpath("database");

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("database/hotel.db");

    if (!db.open()) {
        QMessageBox::critical(nullptr, "Database error", db.lastError().text());
        return false;
    }

    QFile schemaFile("database/schema.sql");
    if (!schemaFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(nullptr, "File error",
                              "Khong tim thay database/schema.sql");
        return false;
    }

    const QString schema = QString::fromUtf8(schemaFile.readAll());
    schemaFile.close();

    const QStringList statements = schema.split(';', Qt::SkipEmptyParts);
    for (const QString &statement : statements) {
        const QString sql = statement.trimmed();
        if (sql.isEmpty()) {
            continue;
        }

        QSqlQuery query;
        if (!query.exec(sql)) {
            QMessageBox::critical(nullptr, "SQL error", query.lastError().text());
            return false;
        }
    }

    return true;
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    if (!initializeDatabase()) {
        return 1;
    }

    MainWindow window;
    window.show();

    return app.exec();
}
