cmake_minimum_required(VERSION 3.16)
project(AurelHouseMember5 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)

find_package(Qt6 REQUIRED COMPONENTS Widgets Sql)

add_executable(AurelHouseMember5
    main.cpp
    src/FrontDeskService.h
    src/FrontDeskService.cpp
    src/MainWindow.h
    src/MainWindow.cpp
)

target_link_libraries(AurelHouseMember5 PRIVATE Qt6::Widgets Qt6::Sql)
