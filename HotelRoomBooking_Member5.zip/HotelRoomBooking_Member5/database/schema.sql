PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL DEFAULT 'Customer',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_number TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'Available'
        CHECK(status IN ('Available', 'Occupied', 'Cleaning', 'Maintenance'))
);

CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_code TEXT NOT NULL UNIQUE,
    customer_id INTEGER,
    customer_name TEXT NOT NULL,
    room_id INTEGER NOT NULL,
    check_in_date TEXT NOT NULL,
    check_out_date TEXT NOT NULL,
    guest_count INTEGER NOT NULL DEFAULT 1,
    total_amount REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'Confirmed'
        CHECK(status IN ('Confirmed', 'CheckedIn', 'Completed', 'Cancelled')),
    payment_status TEXT NOT NULL DEFAULT 'Paid'
        CHECK(payment_status IN ('Pending', 'Paid', 'Failed', 'Refunded')),
    actual_check_in TEXT,
    actual_check_out TEXT,
    FOREIGN KEY(customer_id) REFERENCES users(id),
    FOREIGN KEY(room_id) REFERENCES rooms(id)
);

CREATE TABLE IF NOT EXISTS refunds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id INTEGER,
    amount REAL NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(booking_id) REFERENCES bookings(id)
);

-- Du lieu mau de chay thu. Neu da co du lieu thi khong them trung.
INSERT OR IGNORE INTO users(id, full_name, email, role, is_active)
VALUES (1, 'Admin Demo', 'admin@aurelhouse.test', 'Admin', 1);

INSERT OR IGNORE INTO users(id, full_name, email, role, is_active)
VALUES (2, 'Nguyen Van A', 'customer@aurelhouse.test', 'Customer', 1);

INSERT OR IGNORE INTO rooms(id, room_number, status) VALUES (204, '204', 'Available');
INSERT OR IGNORE INTO rooms(id, room_number, status) VALUES (205, '205', 'Cleaning');
INSERT OR IGNORE INTO rooms(id, room_number, status) VALUES (206, '206', 'Maintenance');

INSERT OR IGNORE INTO bookings(
    id, booking_code, customer_id, customer_name, room_id,
    check_in_date, check_out_date, guest_count, total_amount,
    status, payment_status
)
VALUES (
    1, 'BK1001', 2, 'Nguyen Van A', 204,
    date('now'), date('now', '+2 day'), 2, 1500000,
    'Confirmed', 'Paid'
);
