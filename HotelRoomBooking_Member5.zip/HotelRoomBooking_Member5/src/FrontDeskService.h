#pragma once

#include <QDate>
#include <QDateTime>
#include <QVariantMap>
#include <QString>
#include <QSqlDatabase>

namespace aurel {

struct Session {
    int userId = 0;
    QString role; // "Admin" hoặc "Customer"
};

struct Result {
    bool success = false;
    QString message;
    QVariantMap data;
};

class FrontDeskService {
public:
    explicit FrontDeskService(QSqlDatabase database);

    Result verifyBooking(const Session &session,
                         const QString &bookingCode) const;

    Result checkIn(const Session &session,
                   const QString &bookingCode);

    Result checkOut(const Session &session,
                    const QString &bookingCode);

    Result markRoomReady(const Session &session,
                         int roomId);

    Result setRoomMaintenance(const Session &session,
                              int roomId);

    Result getDashboard(const Session &session) const;

    Result getReports(const Session &session,
                      const QDate &fromDate,
                      const QDate &toDate) const;

private:
    bool isAdmin(const Session &session) const;
    QSqlDatabase database_;
};

} // namespace aurel
