#include "MainWindow.h"

#include <QTabWidget>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QDateEdit>
#include <QMessageBox>
#include <QGroupBox>
#include <QSqlDatabase>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      database_(QSqlDatabase::database()),
      service_(database_)
{
    // Tai khoan Admin demo. Khi ghep voi thanh vien 1, thay bang Session that.
    session_.userId = 1;
    session_.role = "Admin";

    buildUi();
    refreshDashboard();
}

void MainWindow::buildUi()
{
    setWindowTitle("Aurel House - Front Desk");
    resize(900, 620);

    auto *tabs = new QTabWidget(this);
    setCentralWidget(tabs);

    // Tab nghiep vu le tan
    auto *frontDeskTab = new QWidget;
    auto *frontDeskLayout = new QVBoxLayout(frontDeskTab);

    auto *bookingGroup = new QGroupBox("Xac minh Booking / Check-in / Check-out");
    auto *bookingLayout = new QVBoxLayout(bookingGroup);

    auto *bookingForm = new QFormLayout;
    bookingCodeEdit_ = new QLineEdit;
    bookingCodeEdit_->setPlaceholderText("Nhap Booking ID, vi du: BK1001");
    bookingForm->addRow("Booking ID:", bookingCodeEdit_);
    bookingLayout->addLayout(bookingForm);

    auto *verifyButton = new QPushButton("Verify Booking");
    auto *checkInButton = new QPushButton("Check-in");
    auto *checkOutButton = new QPushButton("Check-out");

    auto *bookingButtons = new QHBoxLayout;
    bookingButtons->addWidget(verifyButton);
    bookingButtons->addWidget(checkInButton);
    bookingButtons->addWidget(checkOutButton);
    bookingLayout->addLayout(bookingButtons);

    bookingInfoLabel_ = new QLabel("Thong tin booking se hien thi tai day.");
    bookingInfoLabel_->setWordWrap(true);
    bookingLayout->addWidget(bookingInfoLabel_);

    frontDeskLayout->addWidget(bookingGroup);

    auto *roomGroup = new QGroupBox("Quan ly trang thai phong");
    auto *roomLayout = new QHBoxLayout(roomGroup);
    roomIdEdit_ = new QLineEdit;
    roomIdEdit_->setPlaceholderText("Nhap Room ID");
    auto *readyButton = new QPushButton("Xac nhan phong san sang");
    auto *maintenanceButton = new QPushButton("Chuyen sang Maintenance");
    roomLayout->addWidget(roomIdEdit_);
    roomLayout->addWidget(readyButton);
    roomLayout->addWidget(maintenanceButton);
    frontDeskLayout->addWidget(roomGroup);
    frontDeskLayout->addStretch();

    tabs->addTab(frontDeskTab, "Front Desk");

    // Tab dashboard
    auto *dashboardTab = new QWidget;
    auto *dashboardLayout = new QVBoxLayout(dashboardTab);
    dashboardLabel_ = new QLabel;
    dashboardLabel_->setWordWrap(true);
    dashboardLabel_->setTextInteractionFlags(Qt::TextSelectableByMouse);
    dashboardLayout->addWidget(dashboardLabel_);

    auto *refreshButton = new QPushButton("Lam moi Dashboard");
    dashboardLayout->addWidget(refreshButton);
    dashboardLayout->addStretch();
    tabs->addTab(dashboardTab, "Dashboard");

    // Tab reports
    auto *reportsTab = new QWidget;
    auto *reportsLayout = new QVBoxLayout(reportsTab);
    auto *dateForm = new QFormLayout;

    fromDateEdit_ = new QDateEdit(QDate::currentDate().addMonths(-1));
    toDateEdit_ = new QDateEdit(QDate::currentDate());
    fromDateEdit_->setCalendarPopup(true);
    toDateEdit_->setCalendarPopup(true);

    dateForm->addRow("Tu ngay:", fromDateEdit_);
    dateForm->addRow("Den ngay:", toDateEdit_);
    reportsLayout->addLayout(dateForm);

    auto *reportButton = new QPushButton("Tao bao cao");
    auto *reportLabel = new QLabel("Chon khoang ngay va bam Tao bao cao.");
    reportLabel->setWordWrap(true);
    reportsLayout->addWidget(reportButton);
    reportsLayout->addWidget(reportLabel);
    reportsLayout->addStretch();

    tabs->addTab(reportsTab, "Reports");

    connect(verifyButton, &QPushButton::clicked, this, [this]() {
        const auto result = service_.verifyBooking(session_, bookingCodeEdit_->text());
        showMessage(result);

        if (!result.data.isEmpty()) {
            const auto d = result.data;
            bookingInfoLabel_->setText(
                "Booking: " + d.value("bookingCode").toString() +
                "\nKhach hang: " + d.value("customerName").toString() +
                "\nPhong: " + d.value("roomNumber").toString() +
                "\nNgay nhan: " + d.value("checkInDate").toString() +
                "\nNgay tra: " + d.value("checkOutDate").toString() +
                "\nSo khach: " + d.value("guestCount").toString() +
                "\nTong tien: " + d.value("totalAmount").toString() +
                "\nBooking status: " + d.value("status").toString() +
                "\nPayment status: " + d.value("paymentStatus").toString()
            );
        }
    });

    connect(checkInButton, &QPushButton::clicked, this, [this]() {
        const auto result = service_.checkIn(session_, bookingCodeEdit_->text());
        showMessage(result);
        refreshDashboard();
    });

    connect(checkOutButton, &QPushButton::clicked, this, [this]() {
        const auto result = service_.checkOut(session_, bookingCodeEdit_->text());
        showMessage(result);
        refreshDashboard();
    });

    connect(readyButton, &QPushButton::clicked, this, [this]() {
        bool ok = false;
        const int roomId = roomIdEdit_->text().toInt(&ok);
        if (!ok) {
            QMessageBox::warning(this, "Du lieu khong hop le", "Room ID phai la so.");
            return;
        }
        showMessage(service_.markRoomReady(session_, roomId));
        refreshDashboard();
    });

    connect(maintenanceButton, &QPushButton::clicked, this, [this]() {
        bool ok = false;
        const int roomId = roomIdEdit_->text().toInt(&ok);
        if (!ok) {
            QMessageBox::warning(this, "Du lieu khong hop le", "Room ID phai la so.");
            return;
        }
        showMessage(service_.setRoomMaintenance(session_, roomId));
        refreshDashboard();
    });

    connect(refreshButton, &QPushButton::clicked, this, &MainWindow::refreshDashboard);

    connect(reportButton, &QPushButton::clicked, this, [this, reportLabel]() {
        const auto result = service_.getReports(
            session_, fromDateEdit_->date(), toDateEdit_->date());

        showMessage(result);
        if (result.success) {
            const auto d = result.data;
            reportLabel->setText(
                "So booking: " + d.value("bookingCount").toString() +
                "\nTien thu: " + d.value("income").toString() +
                "\nTien hoan: " + d.value("refunds").toString() +
                "\nDoanh thu rong: " + d.value("netRevenue").toString() +
                "\nSo dem phong co khach: " + d.value("occupiedNights").toString() +
                "\nTai khoan moi: " + d.value("newAccounts").toString()
            );
        }
    });
}

void MainWindow::showMessage(const aurel::Result &result)
{
    if (result.success) {
        QMessageBox::information(this, "Thong bao", result.message);
    } else {
        QMessageBox::warning(this, "Khong the thuc hien", result.message);
    }
}

void MainWindow::refreshDashboard()
{
    const auto result = service_.getDashboard(session_);
    if (!result.success) {
        dashboardLabel_->setText(result.message);
        return;
    }

    const auto d = result.data;
    dashboardLabel_->setText(
        "THONG KE PHONG\n"
        "Available: " + d.value("rooms_Available", 0).toString() +
        "\nOccupied: " + d.value("rooms_Occupied", 0).toString() +
        "\nCleaning: " + d.value("rooms_Cleaning", 0).toString() +
        "\nMaintenance: " + d.value("rooms_Maintenance", 0).toString() +
        "\n\nTHONG KE BOOKING\n"
        "Confirmed: " + d.value("bookings_Confirmed", 0).toString() +
        "\nCheckedIn: " + d.value("bookings_CheckedIn", 0).toString() +
        "\nCompleted: " + d.value("bookings_Completed", 0).toString() +
        "\nCancelled: " + d.value("bookings_Cancelled", 0).toString() +
        "\n\nSo tai khoan Customer dang hoat dong: " +
        d.value("customers", 0).toString()
    );
}
