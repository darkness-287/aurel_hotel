#pragma once

#include <QMainWindow>
#include <QSqlDatabase>
#include "FrontDeskService.h"

class QLineEdit;
class QLabel;
class QDateEdit;
class QSpinBox;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private:
    void buildUi();
    void showMessage(const aurel::Result &result);
    void refreshDashboard();

    QSqlDatabase database_;
    aurel::FrontDeskService service_;
    aurel::Session session_; // Demo: Admin. Khi ghep du an, lay tu AuthService.

    QLineEdit *bookingCodeEdit_;
    QLineEdit *roomIdEdit_;
    QLabel *bookingInfoLabel_;
    QLabel *dashboardLabel_;
    QDateEdit *fromDateEdit_;
    QDateEdit *toDateEdit_;
};
