#include "FrontDeskService.h"

#include <QSqlQuery>
#include <QSqlError>
#include <QSqlRecord>
#include <QVariant>
#include <QDateTime>

namespace aurel {

FrontDeskService::FrontDeskService(QSqlDatabase database)
    : database_(database)
{
}

bool FrontDeskService::isAdmin(const Session &session) const
{
    return session.userId > 0 && session.role == "Admin";
}

Result FrontDeskService::verifyBooking(const Session &session,
                                       const QString &bookingCode) const
{
    if (!isAdmin(session)) {
        return {false, "Ban khong co quyen thuc hien chuc nang nay.", {}};
    }

    if (bookingCode.trimmed().isEmpty()) {
        return {false, "Vui long nhap Booking ID.", {}};
    }

    QSqlQuery query(database_);
    query.prepare(R"(
        SELECT b.id, b.booking_code, b.customer_name, b.room_id,
               r.room_number, b.check_in_date, b.check_out_date,
               b.guest_count, b.total_amount, b.status, b.payment_status
        FROM bookings b
        JOIN rooms r ON r.id = b.room_id
        WHERE b.booking_code = :code
    )");
    query.bindValue(":code", bookingCode.trimmed());

    if (!query.exec()) {
        return {false, "Loi truy van: " + query.lastError().text(), {}};
    }

    if (!query.next()) {
        return {false, "Khong tim thay Booking ID.", {}};
    }

    QVariantMap data;
    data["id"] = query.value(query.record().indexOf("id"));
    data["bookingCode"] = query.value(query.record().indexOf("booking_code"));
    data["customerName"] = query.value(query.record().indexOf("customer_name"));
    data["roomId"] = query.value(query.record().indexOf("room_id"));
    data["roomNumber"] = query.value(query.record().indexOf("room_number"));
    data["checkInDate"] = query.value(query.record().indexOf("check_in_date"));
    data["checkOutDate"] = query.value(query.record().indexOf("check_out_date"));
    data["guestCount"] = query.value(query.record().indexOf("guest_count"));
    data["totalAmount"] = query.value(query.record().indexOf("total_amount"));
    data["status"] = query.value(query.record().indexOf("status"));
    data["paymentStatus"] = query.value(query.record().indexOf("payment_status"));

    if (query.value(query.record().indexOf("status")).toString() != "Confirmed" ||
        query.value(query.record().indexOf("payment_status")).toString() != "Paid") {
        return {false,
                "Booking phai co trang thai Confirmed va thanh toan Paid.",
                data};
    }

    return {true, "Xac minh booking thanh cong.", data};
}

Result FrontDeskService::checkIn(const Session &session,
                                 const QString &bookingCode)
{
    if (!isAdmin(session)) {
        return {false, "Chi Admin moi duoc check-in.", {}};
    }

    if (!database_.transaction()) {
        return {false, "Khong the bat dau giao dich SQLite.", {}};
    }

    QSqlQuery booking(database_);
    booking.prepare(R"(
        SELECT id, room_id, status, payment_status
        FROM bookings
        WHERE booking_code = :code
    )");
    booking.bindValue(":code", bookingCode.trimmed());

    if (!booking.exec() || !booking.next()) {
        database_.rollback();
        return {false, "Khong tim thay booking.", {}};
    }

    const int bookingId = booking.value(booking.record().indexOf("id")).toInt();
    const int roomId = booking.value(booking.record().indexOf("room_id")).toInt();

    if (booking.value(booking.record().indexOf("status")).toString() != "Confirmed" ||
        booking.value(booking.record().indexOf("payment_status")).toString() != "Paid") {
        database_.rollback();
        return {false, "Booking chua Confirmed hoac chua Paid.", {}};
    }

    QSqlQuery room(database_);
    room.prepare("SELECT status FROM rooms WHERE id = :roomId");
    room.bindValue(":roomId", roomId);

    if (!room.exec() || !room.next() ||
        room.value(0).toString() != "Available") {
        database_.rollback();
        return {false, "Phong khong o trang thai Available.", {}};
    }

    QSqlQuery updateBooking(database_);
    updateBooking.prepare(R"(
        UPDATE bookings
        SET status = 'CheckedIn', actual_check_in = :time
        WHERE id = :id AND status = 'Confirmed'
    )");
    updateBooking.bindValue(":time", QDateTime::currentDateTime().toString(Qt::ISODate));
    updateBooking.bindValue(":id", bookingId);

    if (!updateBooking.exec() || updateBooking.numRowsAffected() != 1) {
        database_.rollback();
        return {false, "Khong the cap nhat booking.", {}};
    }

    QSqlQuery updateRoom(database_);
    updateRoom.prepare("UPDATE rooms SET status = 'Occupied' WHERE id = :id AND status = 'Available'");
    updateRoom.bindValue(":id", roomId);

    if (!updateRoom.exec() || updateRoom.numRowsAffected() != 1) {
        database_.rollback();
        return {false, "Khong the cap nhat trang thai phong.", {}};
    }

    if (!database_.commit()) {
        database_.rollback();
        return {false, "Khong the luu giao dich check-in.", {}};
    }

    return {true, "Check-in thanh cong. Phong da chuyen sang Occupied.", {}};
}

Result FrontDeskService::checkOut(const Session &session,
                                  const QString &bookingCode)
{
    if (!isAdmin(session)) {
        return {false, "Chi Admin moi duoc check-out.", {}};
    }

    if (!database_.transaction()) {
        return {false, "Khong the bat dau giao dich SQLite.", {}};
    }

    QSqlQuery booking(database_);
    booking.prepare(R"(
        SELECT id, room_id, status
        FROM bookings
        WHERE booking_code = :code
    )");
    booking.bindValue(":code", bookingCode.trimmed());

    if (!booking.exec() || !booking.next()) {
        database_.rollback();
        return {false, "Khong tim thay booking.", {}};
    }

    if (booking.value(booking.record().indexOf("status")).toString() != "CheckedIn") {
        database_.rollback();
        return {false, "Chi booking CheckedIn moi duoc check-out.", {}};
    }

    const int bookingId = booking.value(booking.record().indexOf("id")).toInt();
    const int roomId = booking.value(booking.record().indexOf("room_id")).toInt();

    QSqlQuery updateBooking(database_);
    updateBooking.prepare(R"(
        UPDATE bookings
        SET status = 'Completed', actual_check_out = :time
        WHERE id = :id AND status = 'CheckedIn'
    )");
    updateBooking.bindValue(":time", QDateTime::currentDateTime().toString(Qt::ISODate));
    updateBooking.bindValue(":id", bookingId);

    if (!updateBooking.exec() || updateBooking.numRowsAffected() != 1) {
        database_.rollback();
        return {false, "Khong the cap nhat booking.", {}};
    }

    // FR-31: Check-out thanh cong thi phong chuyen sang Cleaning.
    QSqlQuery updateRoom(database_);
    updateRoom.prepare("UPDATE rooms SET status = 'Cleaning' WHERE id = :id AND status = 'Occupied'");
    updateRoom.bindValue(":id", roomId);

    if (!updateRoom.exec() || updateRoom.numRowsAffected() != 1) {
        database_.rollback();
        return {false, "Khong the chuyen phong sang Cleaning.", {}};
    }

    if (!database_.commit()) {
        database_.rollback();
        return {false, "Khong the luu giao dich check-out.", {}};
    }

    return {true, "Check-out thanh cong. Phong dang o trang thai Cleaning.", {}};
}

Result FrontDeskService::markRoomReady(const Session &session, int roomId)
{
    if (!isAdmin(session)) {
        return {false, "Chi Admin moi duoc cap nhat phong.", {}};
    }

    QSqlQuery query(database_);
    query.prepare(R"(
        UPDATE rooms
        SET status = 'Available'
        WHERE id = :id AND status IN ('Cleaning', 'Maintenance')
    )");
    query.bindValue(":id", roomId);

    if (!query.exec()) {
        return {false, "Loi SQL: " + query.lastError().text(), {}};
    }

    if (query.numRowsAffected() != 1) {
        return {false, "Khong tim thay phong Cleaning/Maintenance.", {}};
    }

    return {true, "Phong da san sang va chuyen sang Available.", {}};
}

Result FrontDeskService::setRoomMaintenance(const Session &session, int roomId)
{
    if (!isAdmin(session)) {
        return {false, "Chi Admin moi duoc cap nhat phong.", {}};
    }

    QSqlQuery query(database_);
    query.prepare(R"(
        UPDATE rooms
        SET status = 'Maintenance'
        WHERE id = :id AND status = 'Available'
    )");
    query.bindValue(":id", roomId);

    if (!query.exec()) {
        return {false, "Loi SQL: " + query.lastError().text(), {}};
    }

    if (query.numRowsAffected() != 1) {
        return {false, "Chi co the dua phong Available vao Maintenance.", {}};
    }

    return {true, "Phong da chuyen sang Maintenance.", {}};
}

Result FrontDeskService::getDashboard(const Session &session) const
{
    if (!isAdmin(session)) {
        return {false, "Chi Admin moi duoc xem Dashboard.", {}};
    }

    QVariantMap data;

    QSqlQuery roomQuery(database_);
    if (!roomQuery.exec(R"(
        SELECT status, COUNT(*) AS total
        FROM rooms GROUP BY status
    )")) {
        return {false, "Loi doc thong ke phong: " + roomQuery.lastError().text(), {}};
    }

    while (roomQuery.next()) {
        data["rooms_" + roomQuery.value("status").toString()] =
            roomQuery.value("total").toInt();
    }

    QSqlQuery bookingQuery(database_);
    if (!bookingQuery.exec(R"(
        SELECT status, COUNT(*) AS total
        FROM bookings GROUP BY status
    )")) {
        return {false, "Loi doc thong ke booking: " + bookingQuery.lastError().text(), {}};
    }

    while (bookingQuery.next()) {
        data["bookings_" + bookingQuery.value(bookingQuery.record().indexOf("status")).toString()] =
            bookingQuery.value(bookingQuery.record().indexOf("total")).toInt();
    }

    QSqlQuery customerQuery(database_);
    if (!customerQuery.exec("SELECT COUNT(*) FROM users WHERE role = 'Customer' AND is_active = 1")) {
        return {false, "Loi doc so khach: " + customerQuery.lastError().text(), {}};
    }
    if (customerQuery.next()) {
        data["customers"] = customerQuery.value(0).toInt();
    }

    return {true, "Lay Dashboard thanh cong.", data};
}

Result FrontDeskService::getReports(const Session &session,
                                    const QDate &fromDate,
                                    const QDate &toDate) const
{
    if (!isAdmin(session)) {
        return {false, "Chi Admin moi duoc xem bao cao.", {}};
    }

    if (!fromDate.isValid() || !toDate.isValid() || fromDate > toDate) {
        return {false, "Khoang ngay khong hop le.", {}};
    }

    QVariantMap data;
    const QString from = fromDate.toString(Qt::ISODate);
    const QString to = toDate.toString(Qt::ISODate);

    QSqlQuery bookingQuery(database_);
    bookingQuery.prepare(R"(
        SELECT COUNT(*) AS booking_count,
               COALESCE(SUM(CASE WHEN payment_status = 'Paid'
                                 THEN total_amount ELSE 0 END), 0) AS income,
               COALESCE(SUM(
                   CASE WHEN status IN ('CheckedIn', 'Completed')
                   THEN CAST(julianday(check_out_date) - julianday(check_in_date) AS INTEGER)
                   ELSE 0 END
               ), 0) AS occupied_nights
        FROM bookings
        WHERE date(check_in_date) <= date(:toDate)
          AND date(check_out_date) >= date(:fromDate)
    )");
    bookingQuery.bindValue(":fromDate", from);
    bookingQuery.bindValue(":toDate", to);

    if (!bookingQuery.exec() || !bookingQuery.next()) {
        return {false, "Loi tao bao cao booking: " + bookingQuery.lastError().text(), {}};
    }

    data["bookingCount"] = bookingQuery.value(bookingQuery.record().indexOf("booking_count"));
    data["income"] = bookingQuery.value(bookingQuery.record().indexOf("income"));
    data["occupiedNights"] = bookingQuery.value(bookingQuery.record().indexOf("occupied_nights"));

    QSqlQuery refundQuery(database_);
    refundQuery.prepare(R"(
        SELECT COALESCE(SUM(amount), 0)
        FROM refunds
        WHERE date(created_at) BETWEEN date(:fromDate) AND date(:toDate)
    )");
    refundQuery.bindValue(":fromDate", from);
    refundQuery.bindValue(":toDate", to);

    if (!refundQuery.exec() || !refundQuery.next()) {
        return {false, "Loi doc tien hoan: " + refundQuery.lastError().text(), {}};
    }

    const double refunds = refundQuery.value(0).toDouble();
    const double income = data["income"].toDouble();

    data["refunds"] = refunds;
    data["netRevenue"] = income - refunds;

    QSqlQuery userQuery(database_);
    userQuery.prepare(R"(
        SELECT COUNT(*) FROM users
        WHERE date(created_at) BETWEEN date(:fromDate) AND date(:toDate)
    )");
    userQuery.bindValue(":fromDate", from);
    userQuery.bindValue(":toDate", to);

    if (!userQuery.exec() || !userQuery.next()) {
        return {false, "Loi doc so tai khoan moi: " + userQuery.lastError().text(), {}};
    }

    data["newAccounts"] = userQuery.value(0).toInt();

    return {true, "Tao bao cao thanh cong.", data};
}

} // namespace aurel
