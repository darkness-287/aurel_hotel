#include "services/RoomService.h"

namespace aurel {

RoomService::RoomService(RoomRepository& roomRepository)
    : roomRepository_(roomRepository) {}

Result<std::vector<Room>> RoomService::getFeaturedRooms() const {
    RoomSearchCriteria criteria;
    criteria.onlyAvailableForBooking = true;
    return roomRepository_.searchRooms(criteria);
}

Result<std::vector<Room>> RoomService::searchRooms(const RoomSearchCriteria& criteria) const {
    // FR-02: Ngày nhận và ngày trả phải đi cùng nhau, ngày trả phải sau ngày nhận
    if (criteria.stayPeriod.has_value()) {
        const auto& period = criteria.stayPeriod.value();
        if (period.checkInDate.isValid() != period.checkOutDate.isValid()) {
            return Result<std::vector<Room>>::failure(
                ErrorCode::InvalidInput,
                "Ngày nhận phòng và ngày trả phòng phải được chọn cùng nhau."
            );
        }
        if (period.checkInDate.isValid() && period.checkOutDate <= period.checkInDate) {
            return Result<std::vector<Room>>::failure(
                ErrorCode::InvalidInput,
                "Ngày trả phòng phải sau ngày nhận phòng."
            );
        }
    }

    if (criteria.minGuests <= 0) {
        return Result<std::vector<Room>>::failure(
            ErrorCode::InvalidInput,
            "Số khách phải lớn hơn 0."
        );
    }

    return roomRepository_.searchRooms(criteria);
}

Result<RoomDetails> RoomService::getRoomDetails(RoomId roomId, const std::optional<StayPeriod>& stayPeriod) const {
    if (roomId <= 0) {
        return Result<RoomDetails>::failure(ErrorCode::InvalidInput, "Mã phòng không hợp lệ.");
    }
    return roomRepository_.getRoomDetails(roomId, stayPeriod);
}

Result<bool> RoomService::isRoomAvailable(RoomId roomId, const StayPeriod& stayPeriod) const {
    if (roomId <= 0 || !stayPeriod.isValid()) {
        return Result<bool>::failure(ErrorCode::InvalidInput, "Thông tin phòng hoặc khoảng ngày không hợp lệ.");
    }
    return roomRepository_.isRoomAvailable(roomId, stayPeriod);
}

Result<std::vector<Room>> RoomService::getAllRoomsForAdmin(const Session& session) const {
    if (!session.isAdmin()) {
        return Result<std::vector<Room>>::failure(ErrorCode::PermissionDenied, "Chỉ Admin mới có quyền quản lý phòng.");
    }
    return roomRepository_.findAllRooms();
}

Result<RoomId> RoomService::createRoom(const Session& session, const Room& room,
                                       const QStringList& imageUrls, const QStringList& facilityNames) {
    if (!session.isAdmin()) {
        return Result<RoomId>::failure(ErrorCode::PermissionDenied, "Chỉ Admin mới có quyền thêm phòng.");
    }
    if (room.roomNumber().trimmed().isEmpty() || room.roomTypeId() <= 0 || room.pricePerNightCents() < 0) {
        return Result<RoomId>::failure(ErrorCode::InvalidInput, "Vui lòng nhập đầy đủ số phòng, loại phòng và giá hợp lệ.");
    }
    return roomRepository_.createRoom(room, imageUrls, facilityNames);
}

Result<void> RoomService::updateRoom(const Session& session, const Room& room,
                                     const QStringList& imageUrls, const QStringList& facilityNames) {
    if (!session.isAdmin()) {
        return Result<void>::failure(ErrorCode::PermissionDenied, "Chỉ Admin mới có quyền sửa phòng.");
    }
    if (room.id() <= 0 || room.roomNumber().trimmed().isEmpty() || room.pricePerNightCents() < 0) {
        return Result<void>::failure(ErrorCode::InvalidInput, "Dữ liệu cập nhật phòng không hợp lệ.");
    }
    return roomRepository_.updateRoom(room, imageUrls, facilityNames);
}

Result<void> RoomService::deleteRoom(const Session& session, RoomId roomId) {
    if (!session.isAdmin()) {
        return Result<void>::failure(ErrorCode::PermissionDenied, "Chỉ Admin mới có quyền xóa phòng.");
    }

    // FR-13: Chặn xóa phòng có booking tham chiếu
    auto refResult = roomRepository_.hasReferencingBookings(roomId);
    if (!refResult.ok) {
        return Result<void>::failure(refResult.error, refResult.message);
    }
    if (refResult.value) {
        return Result<void>::failure(
            ErrorCode::ConflictInUse,
            "Không thể xóa phòng này vì đã có dữ liệu Booking tham chiếu."
        );
    }

    return roomRepository_.deleteRoom(roomId);
}

Result<std::vector<RoomType>> RoomService::getAllRoomTypes() const {
    return roomRepository_.findAllRoomTypes();
}

Result<RoomTypeId> RoomService::createRoomType(const Session& session, const RoomType& roomType) {
    if (!session.isAdmin()) {
        return Result<RoomTypeId>::failure(ErrorCode::PermissionDenied, "Chỉ Admin mới có quyền thêm loại phòng.");
    }
    if (roomType.name().trimmed().isEmpty() || roomType.capacity() <= 0 || roomType.basePriceCents() < 0) {
        return Result<RoomTypeId>::failure(ErrorCode::InvalidInput, "Tên loại phòng, sức chứa (>0) và giá cơ bản không hợp lệ.");
    }
    return roomRepository_.createRoomType(roomType);
}

Result<void> RoomService::updateRoomType(const Session& session, const RoomType& roomType) {
    if (!session.isAdmin()) {
        return Result<void>::failure(ErrorCode::PermissionDenied, "Chỉ Admin mới có quyền sửa loại phòng.");
    }
    if (roomType.id() <= 0 || roomType.name().trimmed().isEmpty() || roomType.capacity() <= 0 || roomType.basePriceCents() < 0) {
        return Result<void>::failure(ErrorCode::InvalidInput, "Dữ liệu loại phòng không hợp lệ.");
    }
    return roomRepository_.updateRoomType(roomType);
}

Result<void> RoomService::deleteRoomType(const Session& session, RoomTypeId roomTypeId) {
    if (!session.isAdmin()) {
        return Result<void>::failure(ErrorCode::PermissionDenied, "Chỉ Admin mới có quyền xóa loại phòng.");
    }

    // FR-14: Chặn xóa loại phòng còn phòng sử dụng
    auto inUseResult = roomRepository_.hasRoomsUsingType(roomTypeId);
    if (!inUseResult.ok) {
        return Result<void>::failure(inUseResult.error, inUseResult.message);
    }
    if (inUseResult.value) {
        return Result<void>::failure(
            ErrorCode::ConflictInUse,
            "Không thể xóa loại phòng này vì đang có phòng thuộc loại này."
        );
    }

    return roomRepository_.deleteRoomType(roomTypeId);
}

} // namespace aurel
