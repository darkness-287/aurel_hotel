// src/domain/Room.h
#pragma once

#include "common/Types.h"
#include <QString>
#include <QStringList>
#include <vector>

namespace aurel {

struct RoomReviewSummary {
    QString guestName;
    int rating{5};
    QString comment;
    QString createdAt;
};

struct RoomDetails {
    RoomId roomId{0};
    RoomTypeId roomTypeId{0};
    QString roomNumber;
    QString roomTypeName;
    int floor{1};
    int capacity{1};
    int pricePerNightCents{0};
    RoomStatus status{RoomStatus::Available};
    QString description;
    QStringList imageUrls;
    QStringList facilities;
    double averageRating{0.0};
    int reviewCount{0};
    std::vector<RoomReviewSummary> reviews;
    bool isAvailableForSelectedDates{true};
};

class Room {
public:
    Room() = default;
    Room(RoomId id, RoomTypeId roomTypeId, QString roomNumber, int floor,
         QString description, int pricePerNightCents, RoomStatus status);

    RoomId id() const;
    RoomTypeId roomTypeId() const;
    const QString& roomNumber() const;
    int floor() const;
    const QString& description() const;
    int pricePerNightCents() const;
    RoomStatus status() const;

    const QString& roomTypeName() const;
    int capacity() const;
    const QString& primaryImageUrl() const;
    const QStringList& facilities() const;

    void setId(RoomId id);
    void setRoomTypeId(RoomTypeId typeId);
    void setRoomNumber(const QString& roomNumber);
    void setFloor(int floor);
    void setDescription(const QString& description);
    void setPricePerNightCents(int priceCents);
    void setStatus(RoomStatus status);

    void setRoomTypeName(const QString& name);
    void setCapacity(int capacity);
    void setPrimaryImageUrl(const QString& url);
    void setFacilities(const QStringList& facilities);

    bool isBookableStatus() const;

private:
    RoomId id_{0};
    RoomTypeId roomTypeId_{0};
    QString roomNumber_;
    int floor_{1};
    QString description_;
    int pricePerNightCents_{0};
    RoomStatus status_{RoomStatus::Available};

    QString roomTypeName_;
    int capacity_{1};
    QString primaryImageUrl_;
    QStringList facilities_;
};

} // namespace aurel
