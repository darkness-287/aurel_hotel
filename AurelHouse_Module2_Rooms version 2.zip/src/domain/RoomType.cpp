// src/domain/RoomType.h
#pragma once

#include "common/Types.h"
#include <QString>

namespace aurel {

class RoomType {
public:
    RoomType() = default;
    RoomType(RoomTypeId id, QString name, QString description, int capacity, int basePriceCents);

    RoomTypeId id() const;
    const QString& name() const;
    const QString& description() const;
    int capacity() const;
    int basePriceCents() const;

    void setId(RoomTypeId id);
    void setName(const QString& name);
    void setDescription(const QString& description);
    void setCapacity(int capacity);
    void setBasePriceCents(int basePriceCents);

private:
    RoomTypeId id_{0};
    QString name_;
    QString description_;
    int capacity_{1};
    int basePriceCents_{0};
};

} // namespace aurel
