// src/domain/Room.cpp
#include "domain/Room.h"

namespace aurel {

Room::Room(RoomId id, RoomTypeId roomTypeId, QString roomNumber, int floor,
           QString description, int pricePerNightCents, RoomStatus status)
    : id_(id),
      roomTypeId_(roomTypeId),
      roomNumber_(std::move(roomNumber)),
      floor_(floor),
      description_(std::move(description)),
      pricePerNightCents_(pricePerNightCents),
      status_(status) {}

RoomId Room::id() const { return id_; }
RoomTypeId Room::roomTypeId() const { return roomTypeId_; }
const QString& Room::roomNumber() const { return roomNumber_; }
int Room::floor() const { return floor_; }
const QString& Room::description() const { return description_; }
int Room::pricePerNightCents() const { return pricePerNightCents_; }
RoomStatus Room::status() const { return status_; }

const QString& Room::roomTypeName() const { return roomTypeName_; }
int Room::capacity() const { return capacity_; }
const QString& Room::primaryImageUrl() const { return primaryImageUrl_; }
const QStringList& Room::facilities() const { return facilities_; }

void Room::setId(RoomId id) { id_ = id; }
void Room::setRoomTypeId(RoomTypeId typeId) { roomTypeId_ = typeId; }
void Room::setRoomNumber(const QString& roomNumber) { roomNumber_ = roomNumber; }
void Room::setFloor(int floor) { floor_ = floor; }
void Room::setDescription(const QString& description) { description_ = description; }
void Room::setPricePerNightCents(int priceCents) { pricePerNightCents_ = priceCents; }
void Room::setStatus(RoomStatus status) { status_ = status; }

void Room::setRoomTypeName(const QString& name) { roomTypeName_ = name; }
void Room::setCapacity(int capacity) { capacity_ = capacity; }
void Room::setPrimaryImageUrl(const QString& url) { primaryImageUrl_ = url; }
void Room::setFacilities(const QStringList& facilities) { facilities_ = facilities; }

bool Room::isBookableStatus() const {
    return status_ != RoomStatus::Maintenance;
}

} // namespace aurel
