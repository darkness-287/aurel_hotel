// src/ui/ManageRoomsPage.cpp
#include "ui/ManageRoomsPage.h"
#include <QFormLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>

namespace aurel {

ManageRoomsPage::ManageRoomsPage(RoomService& roomService, const Session& session, QWidget* parent)
    : QWidget(parent), roomService_(roomService), session_(session) {
    auto* layout = new QVBoxLayout(this);
    layout->addWidget(new QLabel("<h2>Admin — Quản lý Phòng (FR-13)</h2>"));

    roomsTable_ = new QTableWidget(0, 7, this);
    roomsTable_->setHorizontalHeaderLabels({"ID", "Số phòng", "Loại phòng", "Tầng", "Giá (cent)", "Trạng thái", "Tiện nghi"});
    roomsTable_->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    roomsTable_->setSelectionBehavior(QAbstractItemView::SelectRows);
    roomsTable_->setEditTriggers(QAbstractItemView::NoEditTriggers);
    layout->addWidget(roomsTable_);

    auto* form = new QFormLayout();
    roomNumberEdit_ = new QLineEdit();
    roomTypeCombo_ = new QComboBox();
    floorSpin_ = new QSpinBox();
    floorSpin_->setRange(1, 50);
    priceCentsSpin_ = new QSpinBox();
    priceCentsSpin_->setRange(0, 10000000);
    priceCentsSpin_->setSingleStep(500);
    statusCombo_ = new QComboBox();
    statusCombo_->addItems({"Available", "Occupied", "Cleaning", "Maintenance"});
    descEdit_ = new QLineEdit();
    imagesEdit_ = new QLineEdit();
    imagesEdit_->setPlaceholderText("Ngăn cách bằng dấu phẩy: :/img1.png, :/img2.png");
    facilitiesEdit_ = new QLineEdit();
    facilitiesEdit_->setPlaceholderText("Ngăn cách bằng dấu phẩy: Wi-Fi, Air Conditioning, Mini Bar");

    form->addRow("Số phòng:", roomNumberEdit_);
    form->addRow("Loại phòng:", roomTypeCombo_);
    form->addRow("Tầng:", floorSpin_);
    form->addRow("Giá riêng (cent):", priceCentsSpin_);
    form->addRow("Trạng thái:", statusCombo_);
    form->addRow("Mô tả:", descEdit_);
    form->addRow("Ảnh:", imagesEdit_);
    form->addRow("Tiện nghi:", facilitiesEdit_);
    layout->addLayout(form);

    auto* btnLayout = new QHBoxLayout();
    auto* addBtn = new QPushButton("Thêm phòng");
    auto* updateBtn = new QPushButton("Cập nhật phòng");
    auto* deleteBtn = new QPushButton("Xóa phòng (Demo chặn xóa nếu có Booking)");
    btnLayout->addWidget(addBtn);
    btnLayout->addWidget(updateBtn);
    btnLayout->addWidget(deleteBtn);
    layout->addLayout(btnLayout);

    connect(roomsTable_, &QTableWidget::cellClicked, this, [this](int row, int) {
        selectedRoomId_ = roomsTable_->item(row, 0)->text().toInt();
        roomNumberEdit_->setText(roomsTable_->item(row, 1)->text());
        floorSpin_->setValue(roomsTable_->item(row, 3)->text().toInt());
        priceCentsSpin_->setValue(roomsTable_->item(row, 4)->text().toInt());
        statusCombo_->setCurrentText(roomsTable_->item(row, 5)->text());
        facilitiesEdit_->setText(roomsTable_->item(row, 6)->text());
    });

    connect(addBtn, &QPushButton::clicked, this, [this]() {
        Room room(0, roomTypeCombo_->currentData().toInt(), roomNumberEdit_->text(),
                  floorSpin_->value(), descEdit_->text(), priceCentsSpin_->value(),
                  roomStatusFromString(statusCombo_->currentText()));
        auto res = roomService_.createRoom(session_, room, imagesEdit_->text().split(","), facilitiesEdit_->text().split(","));
        if (!res.ok) {
            QMessageBox::warning(this, "Từ chối", res.message);
            return;
        }
        QMessageBox::information(this, "Thành công", "Đã thêm phòng mới.");
        refreshData();
        emit roomsChanged();
    });

    connect(updateBtn, &QPushButton::clicked, this, [this]() {
        if (selectedRoomId_ <= 0) return;
        Room room(selectedRoomId_, roomTypeCombo_->currentData().toInt(), roomNumberEdit_->text(),
                  floorSpin_->value(), descEdit_->text(), priceCentsSpin_->value(),
                  roomStatusFromString(statusCombo_->currentText()));
        auto res = roomService_.updateRoom(session_, room, imagesEdit_->text().split(","), facilitiesEdit_->text().split(","));
        if (!res.ok) {
            QMessageBox::warning(this, "Từ chối", res.message);
            return;
        }
        QMessageBox::information(this, "Thành công", "Đã cập nhật phòng.");
        refreshData();
        emit roomsChanged();
    });

    connect(deleteBtn, &QPushButton::clicked, this, [this]() {
        if (selectedRoomId_ <= 0) {
            QMessageBox::information(this, "Thông báo", "Vui lòng chọn phòng để xóa.");
            return;
        }
        auto res = roomService_.deleteRoom(session_, selectedRoomId_);
        if (!res.ok) {
            QMessageBox::critical(this, "Xóa bị từ chối (FR-13)", res.message);
            return;
        }
        QMessageBox::information(this, "Thành công", "Đã xóa phòng.");
        selectedRoomId_ = 0;
        refreshData();
        emit roomsChanged();
    });

    refreshData();
}

void ManageRoomsPage::setSession(const Session& session) {
    session_ = session;
    refreshData();
}

void ManageRoomsPage::refreshData() {
    roomTypeCombo_->clear();
    auto typesRes = roomService_.getAllRoomTypes();
    if (typesRes.ok) {
        for (const auto& t : typesRes.value) {
            roomTypeCombo_->addItem(t.name(), t.id());
        }
    }

    roomsTable_->setRowCount(0);
    auto roomsRes = roomService_.getAllRoomsForAdmin(session_);
    if (!roomsRes.ok) return;

    for (const auto& r : roomsRes.value) {
        int row = roomsTable_->rowCount();
        roomsTable_->insertRow(row);
        roomsTable_->setItem(row, 0, new QTableWidgetItem(QString::number(r.id())));
        roomsTable_->setItem(row, 1, new QTableWidgetItem(r.roomNumber()));
        roomsTable_->setItem(row, 2, new QTableWidgetItem(r.roomTypeName()));
        roomsTable_->setItem(row, 3, new QTableWidgetItem(QString::number(r.floor())));
        roomsTable_->setItem(row, 4, new QTableWidgetItem(QString::number(r.pricePerNightCents())));
        roomsTable_->setItem(row, 5, new QTableWidgetItem(roomStatusToString(r.status())));
        roomsTable_->setItem(row, 6, new QTableWidgetItem(r.facilities().join(", ")));
    }
}

} // namespace aurel
