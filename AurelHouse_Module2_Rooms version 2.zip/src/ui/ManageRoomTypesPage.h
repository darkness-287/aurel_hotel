// src/ui/ManageRoomTypesPage.h
#pragma once

#include "common/Types.h"
#include "services/RoomService.h"
#include <QLineEdit>
#include <QSpinBox>
#include <QTableWidget>
#include <QWidget>

namespace aurel {

class ManageRoomTypesPage : public QWidget {
    Q_OBJECT
public:
    explicit ManageRoomTypesPage(RoomService& roomService, const Session& session, QWidget* parent = nullptr);
    void setSession(const Session& session);
    void refreshData();

signals:
    void roomTypesChanged();

private:
    RoomService& roomService_;
    Session session_;

    QTableWidget* typesTable_{nullptr};
    QLineEdit* nameEdit_{nullptr};
    QLineEdit* descEdit_{nullptr};
    QSpinBox* capacitySpin_{nullptr};
    QSpinBox* basePriceSpin_{nullptr};
    RoomTypeId selectedTypeId_{0};
};

} // namespace aurel
