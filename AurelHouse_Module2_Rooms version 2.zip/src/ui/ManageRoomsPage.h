// src/ui/ManageRoomsPage.h
#pragma once

#include "common/Types.h"
#include "services/RoomService.h"
#include <QComboBox>
#include <QLineEdit>
#include <QSpinBox>
#include <QTableWidget>
#include <QWidget>

namespace aurel {

class ManageRoomsPage : public QWidget {
    Q_OBJECT
public:
    explicit ManageRoomsPage(RoomService& roomService, const Session& session, QWidget* parent = nullptr);
    void setSession(const Session& session);
    void refreshData();

signals:
    void roomsChanged();

private:
    RoomService& roomService_;
    Session session_;

    QTableWidget* roomsTable_{nullptr};
    QLineEdit* roomNumberEdit_{nullptr};
    QComboBox* roomTypeCombo_{nullptr};
    QSpinBox* floorSpin_{nullptr};
    QSpinBox* priceCentsSpin_{nullptr};
    QComboBox* statusCombo_{nullptr};
    QLineEdit* descEdit_{nullptr};
    QLineEdit* imagesEdit_{nullptr};
    QLineEdit* facilitiesEdit_{nullptr};
    RoomId selectedRoomId_{0};
};

} // namespace aurel
