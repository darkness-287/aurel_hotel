// src/ui/RoomDetailsPage.cpp
#include "ui/RoomDetailsPage.h"
#include <QHBoxLayout>
#include <QMessageBox>
#include <QVBoxLayout>

namespace aurel {

RoomDetailsPage::RoomDetailsPage(RoomService& roomService, QWidget* parent)
    : QWidget(parent), roomService_(roomService) {
    auto* layout = new QVBoxLayout(this);

    titleLabel_ = new QLabel("<h2>Chi tiết phòng (FR-03)</h2>");
    metaLabel_ = new QLabel();
    layout->addWidget(titleLabel_);
    layout->addWidget(metaLabel_);

    // Bộ chọn ngày để demo kiểm tra trùng lịch FR-07 trực tiếp trên màn hình chi tiết
    auto* dateLayout = new QHBoxLayout();
    checkInEdit_ = new QDateEdit(QDate(2026, 12, 10));
    checkInEdit_->setCalendarPopup(true);
    checkInEdit_->setDisplayFormat("yyyy-MM-dd");

    checkOutEdit_ = new QDateEdit(QDate(2026, 12, 15));
    checkOutEdit_->setCalendarPopup(true);
    checkOutEdit_->setDisplayFormat("yyyy-MM-dd");

    auto* checkBtn = new QPushButton("Kiểm tra phòng trống (FR-07)");
    availabilityLabel_ = new QLabel("<b>Trạng thái lịch:</b> Chưa kiểm tra");

    dateLayout->addWidget(new QLabel("Nhận phòng:"));
    dateLayout->addWidget(checkInEdit_);
    dateLayout->addWidget(new QLabel("Trả phòng:"));
    dateLayout->addWidget(checkOutEdit_);
    dateLayout->addWidget(checkBtn);
    dateLayout->addWidget(availabilityLabel_);
    layout->addLayout(dateLayout);

    descEdit_ = new QTextEdit();
    descEdit_->setReadOnly(true);
    descEdit_->setMaximumHeight(70);
    layout->addWidget(new QLabel("<b>Mô tả:</b>"));
    layout->addWidget(descEdit_);

    auto* listsLayout = new QHBoxLayout();
    facilitiesList_ = new QListWidget();
    imagesList_ = new QListWidget();
    reviewsList_ = new QListWidget();

    auto* facCol = new QVBoxLayout();
    facCol->addWidget(new QLabel("<b>Tiện nghi:</b>"));
    facCol->addWidget(facilitiesList_);

    auto* imgCol = new QVBoxLayout();
    imgCol->addWidget(new QLabel("<b>Hình ảnh:</b>"));
    imgCol->addWidget(imagesList_);

    auto* revCol = new QVBoxLayout();
    revCol->addWidget(new QLabel("<b>Đánh giá của khách (FR-22):</b>"));
    revCol->addWidget(reviewsList_);

    listsLayout->addLayout(facCol);
    listsLayout->addLayout(imgCol);
    listsLayout->addLayout(revCol);
    layout->addLayout(listsLayout);

    bookNowBtn_ = new QPushButton("Tiến hành đặt phòng (Chuyển sang Người 3)");
    layout->addWidget(bookNowBtn_);

    connect(checkBtn, &QPushButton::clicked, this, &RoomDetailsPage::onCheckAvailabilityClicked);
    connect(bookNowBtn_, &QPushButton::clicked, this, [this]() {
        StayPeriod period{checkInEdit_->date(), checkOutEdit_->date()};
        auto avail = roomService_.isRoomAvailable(currentRoomId_, period);
        if (!avail.ok || !avail.value) {
            QMessageBox::warning(this, "Không thể đặt", "Phòng đã trùng lịch hoặc đang bảo trì trong khoảng ngày này.");
            return;
        }
        emit proceedToBookingRequested(currentRoomId_, period);
    });
}

void RoomDetailsPage::loadRoom(RoomId roomId, const std::optional<StayPeriod>& stayPeriod) {
    currentRoomId_ = roomId;
    if (stayPeriod.has_value() && stayPeriod->isValid()) {
        checkInEdit_->setDate(stayPeriod->checkInDate);
        checkOutEdit_->setDate(stayPeriod->checkOutDate);
    }

    auto res = roomService_.getRoomDetails(roomId, stayPeriod);
    if (!res.ok) {
        QMessageBox::warning(this, "Lỗi", res.message);
        return;
    }

    const auto& d = res.value;
    titleLabel_->setText(QString("<h2>Phòng %1 — %2</h2>").arg(d.roomNumber, d.roomTypeName));
    metaLabel_->setText(
        QString("Tầng: %1 | Sức chứa: %2 khách | Giá: $%3/đêm | Đánh giá: %4★ (%5 lượt) | Trạng thái vận hành: %6")
            .arg(d.floor)
            .arg(d.capacity)
            .arg(d.pricePerNightCents / 100.0, 0, 'f', 2)
            .arg(d.averageRating, 0, 'f', 1)
            .arg(d.reviewCount)
            .arg(roomStatusToString(d.status))
    );
    descEdit_->setPlainText(d.description);

    facilitiesList_->clear();
    facilitiesList_->addItems(d.facilities);

    imagesList_->clear();
    imagesList_->addItems(d.imageUrls);

    reviewsList_->clear();
    for (const auto& rev : d.reviews) {
        reviewsList_->addItem(QString("[%1★] %2: %3").arg(rev.rating).arg(rev.guestName, rev.comment));
    }

    onCheckAvailabilityClicked();
}

void RoomDetailsPage::onCheckAvailabilityClicked() {
    if (currentRoomId_ <= 0) return;
    StayPeriod period{checkInEdit_->date(), checkOutEdit_->date()};
    auto res = roomService_.isRoomAvailable(currentRoomId_, period);
    if (!res.ok) {
        availabilityLabel_->setText("<span style='color:red;'>Lỗi: " + res.message + "</span>");
        bookNowBtn_->setEnabled(false);
        return;
    }

    if (res.value) {
        availabilityLabel_->setText("<span style='color:green;'><b>CÒN TRỐNG — Có thể đặt</b></span>");
        bookNowBtn_->setEnabled(true);
    } else {
        availabilityLabel_->setText("<span style='color:red;'><b>TRÙNG LỊCH / BẢO TRÌ — Bị từ chối</b></span>");
        bookNowBtn_->setEnabled(false);
    }
}

} // namespace aurel
