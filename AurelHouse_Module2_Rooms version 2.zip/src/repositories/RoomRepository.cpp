#include "repositories/RoomRepository.h"
#include <QSqlError>
#include <QSqlQuery>
#include <QVariant>

namespace aurel {

RoomRepository::RoomRepository(QSqlDatabase db) : db_(std::move(db)) {}

QStringList RoomRepository::loadFacilitiesForRoom(RoomId roomId) const {
    QStringList list;
    QSqlQuery query(db_);
    query.prepare(
        "SELECT f.name FROM Facility f "
        "JOIN Room_Facility rf ON f.facilityID = rf.facilityID "
        "WHERE rf.roomID = :roomId ORDER BY f.name ASC"
    );
    query.bindValue(":roomId", roomId);
    if (query.exec()) {
        while (query.next()) {
            list.append(query.value(0).toString());
        }
    }
    return list;
}

QStringList RoomRepository::loadImagesForRoom(RoomId roomId) const {
    QStringList list;
    QSqlQuery query(db_);
    query.prepare("SELECT imageUrl FROM RoomImage WHERE roomID = :roomId ORDER BY imageID ASC");
    query.bindValue(":roomId", roomId);
    if (query.exec()) {
        while (query.next()) {
            list.append(query.value(0).toString());
        }
    }
    return list;
}

Result<std::vector<Room>> RoomRepository::findAllRooms() const {
    RoomSearchCriteria criteria;
    criteria.onlyAvailableForBooking = false;
    return searchRooms(criteria);
}

Result<std::vector<Room>> RoomRepository::searchRooms(const RoomSearchCriteria& criteria) const {
    QString sql =
        "SELECT r.roomID, r.roomTypeID, r.roomNumber, r.floor, r.description, "
        "r.pricePerNight, r.status, rt.name AS roomTypeName, rt.capacity, "
        "(SELECT ri.imageUrl FROM RoomImage ri WHERE ri.roomID = r.roomID ORDER BY ri.imageID ASC LIMIT 1) AS primaryImg "
        "FROM Room r "
        "JOIN RoomType rt ON r.roomTypeID = rt.roomTypeID "
        "WHERE 1=1 ";

    if (criteria.onlyAvailableForBooking) {
        // FR-07: Phòng Maintenance bị loại khỏi tìm kiếm đặt mới
        sql += "AND r.status <> 'Maintenance' ";
    }
    if (criteria.minGuests > 1) {
        sql += "AND rt.capacity >= :minGuests ";
    }
    if (criteria.roomTypeId.has_value() && criteria.roomTypeId.value() > 0) {
        sql += "AND r.roomTypeID = :roomTypeId ";
    }
    if (criteria.stayPeriod.has_value() && criteria.stayPeriod->isValid()) {
        // FR-07: Khoảng lưu trú [checkInDate, checkOutDate). Cho phép liền kề (checkOut == checkIn)
        sql +=
            "AND NOT EXISTS ("
            "   SELECT 1 FROM Booking b "
            "   WHERE b.roomID = r.roomID "
            "     AND b.bookingStatus IN ('Confirmed', 'CheckedIn') "
            "     AND :checkIn < b.checkOutDate "
            "     AND b.checkInDate < :checkOut"
            ") ";
    }

    sql += "ORDER BY r.roomNumber ASC";

    QSqlQuery query(db_);
    query.prepare(sql);

    if (criteria.minGuests > 1) {
        query.bindValue(":minGuests", criteria.minGuests);
    }
    if (criteria.roomTypeId.has_value() && criteria.roomTypeId.value() > 0) {
        query.bindValue(":roomTypeId", criteria.roomTypeId.value());
    }
    if (criteria.stayPeriod.has_value() && criteria.stayPeriod->isValid()) {
        query.bindValue(":checkIn", criteria.stayPeriod->checkInDate.toString("yyyy-MM-dd"));
        query.bindValue(":checkOut", criteria.stayPeriod->checkOutDate.toString("yyyy-MM-dd"));
    }

    if (!query.exec()) {
        return Result<std::vector<Room>>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }

    std::vector<Room> rooms;
    while (query.next()) {
        Room room(
            query.value("roomID").toInt(),
            query.value("roomTypeID").toInt(),
            query.value("roomNumber").toString(),
            query.value("floor").toInt(),
            query.value("description").toString(),
            query.value("pricePerNight").toInt(),
            roomStatusFromString(query.value("status").toString())
        );
        room.setRoomTypeName(query.value("roomTypeName").toString());
        room.setCapacity(query.value("capacity").toInt());
        room.setPrimaryImageUrl(query.value("primaryImg").toString());
        room.setFacilities(loadFacilitiesForRoom(room.id()));
        rooms.push_back(std::move(room));
    }

    return Result<std::vector<Room>>::success(std::move(rooms));
}

Result<bool> RoomRepository::isRoomAvailable(RoomId roomId, const StayPeriod& stayPeriod) const {
    if (!stayPeriod.isValid()) {
        return Result<bool>::failure(ErrorCode::InvalidInput, "Khoảng ngày lưu trú không hợp lệ.");
    }

    // 1. Kiểm tra trạng thái phòng hiện tại (Maintenance không thể đặt mới)
    QSqlQuery roomQuery(db_);
    roomQuery.prepare("SELECT status FROM Room WHERE roomID = :roomId");
    roomQuery.bindValue(":roomId", roomId);

    if (!roomQuery.exec()) {
        return Result<bool>::failure(ErrorCode::DatabaseError, roomQuery.lastError().text());
    }
    if (!roomQuery.next()) {
        return Result<bool>::failure(ErrorCode::RoomNotFound, "Không tìm thấy phòng.");
    }

    QString statusStr = roomQuery.value(0).toString();
    if (statusStr == "Maintenance") {
        return Result<bool>::success(false);
    }

    // 2. Kiểm tra trùng lịch với Booking Confirmed hoặc CheckedIn
    QSqlQuery overlapQuery(db_);
    overlapQuery.prepare(
        "SELECT COUNT(*) FROM Booking "
        "WHERE roomID = :roomId "
        "  AND bookingStatus IN ('Confirmed', 'CheckedIn') "
        "  AND :checkIn < checkOutDate "
        "  AND checkInDate < :checkOut"
    );
    overlapQuery.bindValue(":roomId", roomId);
    overlapQuery.bindValue(":checkIn", stayPeriod.checkInDate.toString("yyyy-MM-dd"));
    overlapQuery.bindValue(":checkOut", stayPeriod.checkOutDate.toString("yyyy-MM-dd"));

    if (!overlapQuery.exec() || !overlapQuery.next()) {
        return Result<bool>::failure(ErrorCode::DatabaseError, overlapQuery.lastError().text());
    }

    int conflictCount = overlapQuery.value(0).toInt();
    return Result<bool>::success(conflictCount == 0);
}

Result<RoomDetails> RoomRepository::getRoomDetails(RoomId roomId, const std::optional<StayPeriod>& stayPeriod) const {
    QSqlQuery query(db_);
    query.prepare(
        "SELECT r.roomID, r.roomTypeID, r.roomNumber, r.floor, r.description, "
        "r.pricePerNight, r.status, rt.name AS roomTypeName, rt.capacity "
        "FROM Room r "
        "JOIN RoomType rt ON r.roomTypeID = rt.roomTypeID "
        "WHERE r.roomID = :roomId"
    );
    query.bindValue(":roomId", roomId);

    if (!query.exec()) {
        return Result<RoomDetails>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }
    if (!query.next()) {
        return Result<RoomDetails>::failure(ErrorCode::RoomNotFound, "Không tìm thấy thông tin phòng.");
    }

    RoomDetails details;
    details.roomId = query.value("roomID").toInt();
    details.roomTypeId = query.value("roomTypeID").toInt();
    details.roomNumber = query.value("roomNumber").toString();
    details.roomTypeName = query.value("roomTypeName").toString();
    details.floor = query.value("floor").toInt();
    details.capacity = query.value("capacity").toInt();
    details.pricePerNightCents = query.value("pricePerNight").toInt();
    details.status = roomStatusFromString(query.value("status").toString());
    details.description = query.value("description").toString();
    details.imageUrls = loadImagesForRoom(roomId);
    details.facilities = loadFacilitiesForRoom(roomId);

    // Tải đánh giá & điểm trung bình (FR-03 / FR-22)
    QSqlQuery revQuery(db_);
    revQuery.prepare(
        "SELECT u.fullName, rev.rating, rev.comment, rev.createdAt "
        "FROM Review rev "
        "JOIN Booking b ON rev.bookingID = b.bookingID "
        "JOIN \"User\" u ON b.userID = u.userID "
        "WHERE rev.roomID = :roomId ORDER BY rev.createdAt DESC"
    );
    revQuery.bindValue(":roomId", roomId);

    int totalRating = 0;
    if (revQuery.exec()) {
        while (revQuery.next()) {
            RoomReviewSummary item;
            item.guestName = revQuery.value(0).toString();
            item.rating = revQuery.value(1).toInt();
            item.comment = revQuery.value(2).toString();
            item.createdAt = revQuery.value(3).toString();
            totalRating += item.rating;
            details.reviews.push_back(std::move(item));
        }
    }
    details.reviewCount = static_cast<int>(details.reviews.size());
    details.averageRating = details.reviewCount > 0
        ? static_cast<double>(totalRating) / details.reviewCount
        : 0.0;

    if (stayPeriod.has_value() && stayPeriod->isValid()) {
        auto availRes = isRoomAvailable(roomId, stayPeriod.value());
        if (!availRes.ok) {
            return Result<RoomDetails>::failure(availRes.error, availRes.message);
        }
        details.isAvailableForSelectedDates = availRes.value;
    } else {
        details.isAvailableForSelectedDates = (details.status != RoomStatus::Maintenance);
    }

    return Result<RoomDetails>::success(std::move(details));
}

void RoomRepository::syncRoomImagesAndFacilities(RoomId roomId, const QStringList& imageUrls, const QStringList& facilityNames) {
    QSqlQuery delImg(db_);
    delImg.prepare("DELETE FROM RoomImage WHERE roomID = :roomId");
    delImg.bindValue(":roomId", roomId);
    delImg.exec();

    for (const QString& rawUrl : imageUrls) {
        QString url = rawUrl.trimmed();
        if (url.isEmpty()) continue;
        QSqlQuery insImg(db_);
        insImg.prepare("INSERT INTO RoomImage (roomID, imageUrl) VALUES (:roomId, :url)");
        insImg.bindValue(":roomId", roomId);
        insImg.bindValue(":url", url);
        insImg.exec();
    }

    QSqlQuery delFac(db_);
    delFac.prepare("DELETE FROM Room_Facility WHERE roomID = :roomId");
    delFac.bindValue(":roomId", roomId);
    delFac.exec();

    for (const QString& rawName : facilityNames) {
        QString name = rawName.trimmed();
        if (name.isEmpty()) continue;

        QSqlQuery insFacMaster(db_);
        insFacMaster.prepare("INSERT OR IGNORE INTO Facility (name) VALUES (:name)");
        insFacMaster.bindValue(":name", name);
        insFacMaster.exec();

        QSqlQuery linkFac(db_);
        linkFac.prepare(
            "INSERT OR IGNORE INTO Room_Facility (roomID, facilityID) "
            "SELECT :roomId, facilityID FROM Facility WHERE name = :name"
        );
        linkFac.bindValue(":roomId", roomId);
        linkFac.bindValue(":name", name);
        linkFac.exec();
    }
}

Result<RoomId> RoomRepository::createRoom(const Room& room, const QStringList& imageUrls, const QStringList& facilityNames) {
    db_.transaction();

    QSqlQuery query(db_);
    query.prepare(
        "INSERT INTO Room (roomTypeID, roomNumber, floor, description, pricePerNight, status) "
        "VALUES (:typeId, :number, :floor, :desc, :price, :status)"
    );
    query.bindValue(":typeId", room.roomTypeId());
    query.bindValue(":number", room.roomNumber().trimmed());
    query.bindValue(":floor", room.floor());
    query.bindValue(":desc", room.description());
    query.bindValue(":price", room.pricePerNightCents());
    query.bindValue(":status", roomStatusToString(room.status()));

    if (!query.exec()) {
        db_.rollback();
        return Result<RoomId>::failure(ErrorCode::DatabaseError, "Lỗi tạo phòng (có thể trùng số phòng): " + query.lastError().text());
    }

    RoomId newId = query.lastInsertId().toInt();
    syncRoomImagesAndFacilities(newId, imageUrls, facilityNames);

    if (!db_.commit()) {
        db_.rollback();
        return Result<RoomId>::failure(ErrorCode::DatabaseError, db_.lastError().text());
    }
    return Result<RoomId>::success(newId);
}

Result<void> RoomRepository::updateRoom(const Room& room, const QStringList& imageUrls, const QStringList& facilityNames) {
    db_.transaction();

    QSqlQuery query(db_);
    query.prepare(
        "UPDATE Room SET roomTypeID = :typeId, roomNumber = :number, floor = :floor, "
        "description = :desc, pricePerNight = :price, status = :status "
        "WHERE roomID = :roomId"
    );
    query.bindValue(":typeId", room.roomTypeId());
    query.bindValue(":number", room.roomNumber().trimmed());
    query.bindValue(":floor", room.floor());
    query.bindValue(":desc", room.description());
    query.bindValue(":price", room.pricePerNightCents());
    query.bindValue(":status", roomStatusToString(room.status()));
    query.bindValue(":roomId", room.id());

    if (!query.exec()) {
        db_.rollback();
        return Result<void>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }

    syncRoomImagesAndFacilities(room.id(), imageUrls, facilityNames);

    if (!db_.commit()) {
        db_.rollback();
        return Result<void>::failure(ErrorCode::DatabaseError, db_.lastError().text());
    }
    return Result<void>::success();
}

Result<bool> RoomRepository::hasReferencingBookings(RoomId roomId) const {
    QSqlQuery query(db_);
    query.prepare("SELECT COUNT(*) FROM Booking WHERE roomID = :roomId");
    query.bindValue(":roomId", roomId);

    if (!query.exec() || !query.next()) {
        return Result<bool>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }
    return Result<bool>::success(query.value(0).toInt() > 0);
}

Result<void> RoomRepository::deleteRoom(RoomId roomId) {
    QSqlQuery query(db_);
    query.prepare("DELETE FROM Room WHERE roomID = :roomId");
    query.bindValue(":roomId", roomId);

    if (!query.exec()) {
        return Result<void>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }
    return Result<void>::success();
}

Result<std::vector<RoomType>> RoomRepository::findAllRoomTypes() const {
    QSqlQuery query(db_);
    query.prepare("SELECT roomTypeID, name, description, capacity, basePrice FROM RoomType ORDER BY roomTypeID ASC");

    if (!query.exec()) {
        return Result<std::vector<RoomType>>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }

    std::vector<RoomType> list;
    while (query.next()) {
        list.emplace_back(
            query.value("roomTypeID").toInt(),
            query.value("name").toString(),
            query.value("description").toString(),
            query.value("capacity").toInt(),
            query.value("basePrice").toInt()
        );
    }
    return Result<std::vector<RoomType>>::success(std::move(list));
}

Result<RoomTypeId> RoomRepository::createRoomType(const RoomType& roomType) {
    QSqlQuery query(db_);
    query.prepare(
        "INSERT INTO RoomType (name, description, capacity, basePrice) "
        "VALUES (:name, :desc, :cap, :price)"
    );
    query.bindValue(":name", roomType.name().trimmed());
    query.bindValue(":desc", roomType.description());
    query.bindValue(":cap", roomType.capacity());
    query.bindValue(":price", roomType.basePriceCents());

    if (!query.exec()) {
        return Result<RoomTypeId>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }
    return Result<RoomTypeId>::success(query.lastInsertId().toInt());
}

Result<void> RoomRepository::updateRoomType(const RoomType& roomType) {
    QSqlQuery query(db_);
    query.prepare(
        "UPDATE RoomType SET name = :name, description = :desc, capacity = :cap, basePrice = :price "
        "WHERE roomTypeID = :id"
    );
    query.bindValue(":name", roomType.name().trimmed());
    query.bindValue(":desc", roomType.description());
    query.bindValue(":cap", roomType.capacity());
    query.bindValue(":price", roomType.basePriceCents());
    query.bindValue(":id", roomType.id());

    if (!query.exec()) {
        return Result<void>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }
    return Result<void>::success();
}

Result<bool> RoomRepository::hasRoomsUsingType(RoomTypeId roomTypeId) const {
    QSqlQuery query(db_);
    query.prepare("SELECT COUNT(*) FROM Room WHERE roomTypeID = :id");
    query.bindValue(":id", roomTypeId);

    if (!query.exec() || !query.next()) {
        return Result<bool>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }
    return Result<bool>::success(query.value(0).toInt() > 0);
}

Result<void> RoomRepository::deleteRoomType(RoomTypeId roomTypeId) {
    QSqlQuery query(db_);
    query.prepare("DELETE FROM RoomType WHERE roomTypeID = :id");
    query.bindValue(":id", roomTypeId);

    if (!query.exec()) {
        return Result<void>::failure(ErrorCode::DatabaseError, query.lastError().text());
    }
    return Result<void>::success();
}

} // namespace aurel