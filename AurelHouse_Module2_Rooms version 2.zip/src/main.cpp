#include "common/Types.h"
#include "repositories/RoomRepository.h"
#include "services/RoomService.h"
#include "ui/HomepagePage.h"
#include "ui/ManageRoomTypesPage.h"
#include "ui/ManageRoomsPage.h"
#include "ui/RoomDetailsPage.h"
#include "ui/RoomSearchPage.h"

#include <QApplication>
#include <QComboBox>
#include <QFile>
#include <QHBoxLayout>
#include <QLabel>
#include <QMainWindow>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QTabWidget>
#include <QTextStream>
#include <QVBoxLayout>

namespace {

bool executeSqlScript(QSqlDatabase& db, const QString& filePath) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }
    QString content = QTextStream(&file).readAll();
    // Tách câu lệnh đơn giản theo dấu ; (bỏ qua BEGIN/END trigger nếu chạy bằng sqlite3 CLI)
    QStringList statements = content.split(';', Qt::SkipEmptyParts);
    QSqlQuery query(db);
    for (const QString& stmt : statements) {
        QString trimmed = stmt.trimmed();
        if (trimmed.isEmpty() || trimmed.startsWith("--")) continue;
        query.exec(trimmed);
    }
    return true;
}

QSqlDatabase initDatabase() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("aurel_house.db");
    if (!db.open()) {
        return db;
    }

    QSqlQuery pragmaQuery(db);
    pragmaQuery.exec("PRAGMA foreign_keys = ON;");

    // Nếu DB mới chưa có bảng Room, tự nạp schema và seed dữ liệu mẫu
    if (!db.tables().contains("Room")) {
        executeSqlScript(db, "database/schema.sql");
        executeSqlScript(db, "database/seed_part2.sql");
    }
    return db;
}

} // namespace

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);

    QSqlDatabase db = initDatabase();
    if (!db.isOpen()) {
        QMessageBox::critical(nullptr, "Database Error", "Không thể mở SQLite aurel_house.db");
        return 1;
    }

    aurel::RoomRepository roomRepo(db);
    aurel::RoomService roomService(roomRepo);

    // Phiên mặc định để test cả quyền Admin và Customer
    aurel::Session currentSession{2, aurel::UserRole::Admin, "Tran Thi Binh (Admin)"};

    QMainWindow mainWindow;
    mainWindow.setWindowTitle("Aurel House — Hotel Room Booking System (Module 2: Phòng)");
    mainWindow.resize(1100, 720);

    auto* central = new QWidget(&mainWindow);
    auto* rootLayout = new QVBoxLayout(central);

    // Thanh chuyển vai trò demo phân quyền
    auto* topBar = new QHBoxLayout();
    auto* roleCombo = new QComboBox();
    roleCombo->addItem("Admin (Tran Thi Binh)", static_cast<int>(aurel::UserRole::Admin));
    roleCombo->addItem("Customer (Nguyen Van An)", static_cast<int>(aurel::UserRole::Customer));
    roleCombo->addItem("Guest (Khách vãng lai)", static_cast<int>(aurel::UserRole::Guest));

    topBar->addWidget(new QLabel("<b>Phiên đăng nhập hiện tại (Demo phân quyền):</b>"));
    topBar->addWidget(roleCombo);
    topBar->addStretch();
    rootLayout->addLayout(topBar);

    auto* tabs = new QTabWidget();
    auto* homePage = new aurel::HomepagePage(roomService);
    auto* searchPage = new aurel::RoomSearchPage(roomService);
    auto* detailsPage = new aurel::RoomDetailsPage(roomService);
    auto* manageRoomsPage = new aurel::ManageRoomsPage(roomService, currentSession);
    auto* manageTypesPage = new aurel::ManageRoomTypesPage(roomService, currentSession);

    tabs->addTab(homePage, "1. Homepage (FR-01)");
    tabs->addTab(searchPage, "2. Room Search (FR-02)");
    tabs->addTab(detailsPage, "3. Room Details (FR-03/07)");
    tabs->addTab(manageRoomsPage, "4. Manage Rooms (FR-13)");
    tabs->addTab(manageTypesPage, "5. Manage Room Types (FR-14)");
    rootLayout->addWidget(tabs);

    // Kết nối điều hướng giữa các màn hình
    QObject::connect(homePage, &aurel::HomepagePage::searchRequested,
                     [tabs, searchPage](const aurel::StayPeriod& period, int guests) {
        searchPage->applyExternalSearch(period, guests);
        tabs->setCurrentWidget(searchPage);
    });

    auto openDetails = [tabs, detailsPage](aurel::RoomId roomId, const std::optional<aurel::StayPeriod>& period) {
        detailsPage->loadRoom(roomId, period);
        tabs->setCurrentWidget(detailsPage);
    };
    QObject::connect(homePage, &aurel::HomepagePage::roomSelected, openDetails);
    QObject::connect(searchPage, &aurel::RoomSearchPage::roomSelected, openDetails);

    QObject::connect(detailsPage, &aurel::RoomDetailsPage::proceedToBookingRequested,
                     [&mainWindow](aurel::RoomId roomId, const aurel::StayPeriod& period) {
        QMessageBox::information(
            &mainWindow,
            "Chuyển sang Module 3 (Thanh toán)",
            QString("Đã xác nhận phòng ID %1 trống từ %2 đến %3.\nSẵn sàng chuyển sang CheckoutService!")
                .arg(roomId)
                .arg(period.checkInDate.toString("yyyy-MM-dd"))
                .arg(period.checkOutDate.toString("yyyy-MM-dd"))
        );
    });

    // Đồng bộ dữ liệu khi Admin thêm/sửa/xóa
    QObject::connect(manageRoomsPage, &aurel::ManageRoomsPage::roomsChanged, [homePage, searchPage]() {
        homePage->refreshFeaturedRooms();
        searchPage->onSearchClicked();
    });
    QObject::connect(manageTypesPage, &aurel::ManageRoomTypesPage::roomTypesChanged, [searchPage, manageRoomsPage]() {
        searchPage->reloadRoomTypes();
        manageRoomsPage->refreshData();
    });

    // Đổi vai trò trên thanh công cụ để test chặn quyền Admin
    QObject::connect(roleCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
                     [roleCombo, &currentSession, manageRoomsPage, manageTypesPage](int idx) {
        auto role = static_cast<aurel::UserRole>(roleCombo->itemData(idx).toInt());
        currentSession.role = role;
        currentSession.userId = (role == aurel::UserRole::Admin) ? 2 : (role == aurel::UserRole::Customer ? 1 : 0);
        manageRoomsPage->setSession(currentSession);
        manageTypesPage->setSession(currentSession);
    });

    mainWindow.setCentralWidget(central);
    mainWindow.show();

    return app.exec();
}