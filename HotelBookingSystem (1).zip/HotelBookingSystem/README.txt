HOTEL BOOKING SYSTEM - C++ CONSOLE PROJECT
==========================================

Features
--------
1. Register a customer account
2. Login and logout
3. View available hotel rooms
4. Book a room
5. View bookings for the logged-in customer
6. View and edit profile (name, email, password)

Files
-----
main.cpp       - Main menu and program entry point
User.h         - User data structure
Room.h         - Room data structure
Booking.h      - Booking data structure
HotelSystem.h  - Main system logic

Requirements
------------
- Windows 10/11
- Visual Studio Code
- A C++ compiler such as g++ (MSYS2 MinGW-w64)

Compile and run (VS Code Terminal)
----------------------------------
1. Open the HotelBookingSystem folder in VS Code.
2. Open Terminal > New Terminal.
3. Compile:
       g++ -std=c++17 -Wall -Wextra main.cpp -o HotelBookingSystem.exe
4. Run in PowerShell:
       .\HotelBookingSystem.exe

Important notes
---------------
- This is a learning/demo project. Data is stored in memory only.
- Accounts and bookings are cleared when the program is closed.
- A room can be booked only once in the current program run.
- Passwords are plain text in memory; do not use this design for a real service.
