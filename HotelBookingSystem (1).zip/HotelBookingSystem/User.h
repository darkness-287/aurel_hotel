#ifndef USER_H
#define USER_H

#include <string>

struct User {
    int id;
    std::string fullName;
    std::string email;
    std::string password;
};

#endif
