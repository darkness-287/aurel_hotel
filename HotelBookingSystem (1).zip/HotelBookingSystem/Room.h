#ifndef ROOM_H
#define ROOM_H

#include <string>

struct Room {
    int id;
    std::string type;
    double pricePerNight;
    bool available;
};

#endif
