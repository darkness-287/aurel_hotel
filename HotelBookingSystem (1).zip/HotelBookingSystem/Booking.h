#ifndef BOOKING_H
#define BOOKING_H

struct Booking {
    int id;
    int userId;
    int roomId;
    int nights;
    double totalPrice;
};

#endif
