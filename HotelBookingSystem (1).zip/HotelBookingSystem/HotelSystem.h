#ifndef HOTEL_SYSTEM_H
#define HOTEL_SYSTEM_H

#include <iostream>
#include <vector>
#include <string>
#include <limits>
#include "User.h"
#include "Room.h"
#include "Booking.h"

class HotelSystem {
private:
    std::vector<User> users;
    std::vector<Room> rooms;
    std::vector<Booking> bookings;
    int nextUserId = 1;
    int nextBookingId = 1;
    int loggedInUserId = -1;

    void clearInputLine() {
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    User* findUserById(int id) {
        for (auto& user : users) {
            if (user.id == id) return &user;
        }
        return nullptr;
    }

    Room* findRoomById(int id) {
        for (auto& room : rooms) {
            if (room.id == id) return &room;
        }
        return nullptr;
    }

public:
    HotelSystem() {
        rooms.push_back({101, "Standard", 500000, true});
        rooms.push_back({102, "Standard", 500000, true});
        rooms.push_back({201, "Deluxe", 800000, true});
        rooms.push_back({202, "Deluxe", 800000, true});
        rooms.push_back({301, "Suite", 1200000, true});
    }

    void registerUser() {
        User user{};
        std::cout << "\n========== REGISTER ==========\n";
        user.id = nextUserId++;

        clearInputLine();
        std::cout << "Full name: ";
        std::getline(std::cin, user.fullName);

        std::cout << "Email: ";
        std::getline(std::cin, user.email);

        for (const auto& existing : users) {
            if (existing.email == user.email) {
                std::cout << "This email is already registered.\n";
                --nextUserId;
                return;
            }
        }

        std::cout << "Password: ";
        std::getline(std::cin, user.password);

        if (user.fullName.empty() || user.email.empty() || user.password.empty()) {
            std::cout << "Fields cannot be empty. Registration cancelled.\n";
            --nextUserId;
            return;
        }

        users.push_back(user);
        std::cout << "Registration successful. Your user ID is " << user.id << ".\n";
    }

    void loginUser() {
        if (loggedInUserId != -1) {
            std::cout << "A user is already logged in. Please logout first.\n";
            return;
        }

        std::string email, password;
        clearInputLine();
        std::cout << "\n========== LOGIN ==========\n";
        std::cout << "Email: ";
        std::getline(std::cin, email);
        std::cout << "Password: ";
        std::getline(std::cin, password);

        for (const auto& user : users) {
            if (user.email == email && user.password == password) {
                loggedInUserId = user.id;
                std::cout << "Login successful. Welcome, " << user.fullName << "!\n";
                return;
            }
        }
        std::cout << "Incorrect email or password, or account does not exist.\n";
    }

    void logout() {
        if (loggedInUserId == -1) {
            std::cout << "No user is currently logged in.\n";
            return;
        }
        loggedInUserId = -1;
        std::cout << "Logout successful.\n";
    }

    void showRooms() const {
        std::cout << "\n========== ROOM LIST ==========\n";
        std::cout << "ID\tType\t\tPrice/night\tStatus\n";
        for (const auto& room : rooms) {
            std::cout << room.id << "\t" << room.type << "\t\t"
                      << room.pricePerNight << " VND\t"
                      << (room.available ? "Available" : "Booked") << '\n';
        }
    }

    void bookRoom() {
        if (loggedInUserId == -1) {
            std::cout << "Please login before booking a room.\n";
            return;
        }

        showRooms();
        int roomId, nights;
        std::cout << "Enter room ID: ";
        if (!(std::cin >> roomId)) {
            std::cout << "Invalid room ID.\n";
            std::cin.clear();
            clearInputLine();
            return;
        }

        Room* room = findRoomById(roomId);
        if (room == nullptr) {
            std::cout << "Room not found.\n";
            return;
        }
        if (!room->available) {
            std::cout << "This room is already booked.\n";
            return;
        }

        std::cout << "Number of nights: ";
        if (!(std::cin >> nights) || nights <= 0) {
            std::cout << "Number of nights must be greater than zero.\n";
            std::cin.clear();
            clearInputLine();
            return;
        }

        Booking booking{nextBookingId++, loggedInUserId, roomId,
                        nights, room->pricePerNight * nights};
        bookings.push_back(booking);
        room->available = false;

        std::cout << "Booking successful! Booking ID: " << booking.id
                  << "\nTotal price: " << booking.totalPrice << " VND\n";
    }

    void showMyBookings() const {
        if (loggedInUserId == -1) {
            std::cout << "Please login to view your bookings.\n";
            return;
        }

        std::cout << "\n========== MY BOOKINGS ==========\n";
        bool found = false;
        for (const auto& booking : bookings) {
            if (booking.userId == loggedInUserId) {
                found = true;
                std::cout << "Booking ID: " << booking.id
                          << " | Room ID: " << booking.roomId
                          << " | Nights: " << booking.nights
                          << " | Total: " << booking.totalPrice << " VND\n";
            }
        }
        if (!found) std::cout << "You have no bookings yet.\n";
    }

    void manageProfile() {
        if (loggedInUserId == -1) {
            std::cout << "Please login before managing your profile.\n";
            return;
        }

        User* user = findUserById(loggedInUserId);
        if (user == nullptr) {
            std::cout << "User profile could not be found.\n";
            return;
        }

        int choice;
        do {
            std::cout << "\n========== PROFILE MANAGEMENT ==========\n";
            std::cout << "1. View profile\n";
            std::cout << "2. Change full name\n";
            std::cout << "3. Change email\n";
            std::cout << "4. Change password\n";
            std::cout << "0. Back to main menu\n";
            std::cout << "Choose: ";

            if (!(std::cin >> choice)) {
                std::cout << "Please enter a number.\n";
                std::cin.clear();
                clearInputLine();
                continue;
            }

            switch (choice) {
                case 1:
                    std::cout << "User ID: " << user->id
                              << "\nFull name: " << user->fullName
                              << "\nEmail: " << user->email << '\n';
                    break;
                case 2:
                    clearInputLine();
                    std::cout << "New full name: ";
                    std::getline(std::cin, user->fullName);
                    std::cout << "Name updated.\n";
                    break;
                case 3: {
                    clearInputLine();
                    std::string newEmail;
                    std::cout << "New email: ";
                    std::getline(std::cin, newEmail);
                    bool used = false;
                    for (const auto& other : users) {
                        if (other.id != user->id && other.email == newEmail) {
                            used = true;
                            break;
                        }
                    }
                    if (newEmail.empty() || used) {
                        std::cout << "Email is empty or already used.\n";
                    } else {
                        user->email = newEmail;
                        std::cout << "Email updated.\n";
                    }
                    break;
                }
                case 4:
                    clearInputLine();
                    std::cout << "New password: ";
                    std::getline(std::cin, user->password);
                    std::cout << "Password updated.\n";
                    break;
                case 0:
                    break;
                default:
                    std::cout << "Invalid choice.\n";
            }
        } while (choice != 0);
    }
};

#endif
