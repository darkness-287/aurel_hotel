#include <iostream>
#include <limits>
#include "HotelSystem.h"

using namespace std;

int main() {
    HotelSystem hotel;
    int choice = -1;

    do {
        cout << "\n========== HOTEL BOOKING SYSTEM ==========\n";
        cout << "1. Register\n";
        cout << "2. Login\n";
        cout << "3. View available rooms\n";
        cout << "4. Book a room\n";
        cout << "5. View my bookings\n";
        cout << "6. Manage profile\n";
        cout << "7. Logout\n";
        cout << "0. Exit\n";
        cout << "Choose: ";

        if (!(cin >> choice)) {
            cout << "Please enter a number.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
            case 1:
                hotel.registerUser();
                break;
            case 2:
                hotel.loginUser();
                break;
            case 3:
                hotel.showRooms();
                break;
            case 4:
                hotel.bookRoom();
                break;
            case 5:
                hotel.showMyBookings();
                break;
            case 6:
                hotel.manageProfile();
                break;
            case 7:
                hotel.logout();
                break;
            case 0:
                cout << "Thank you for using Hotel Booking System!\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 0);

    return 0;
}
